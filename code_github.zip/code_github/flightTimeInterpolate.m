function [flightTimeGrid, allocationGrid] = flightTimeInterpolate(path, ...
    fine_obs_file, fine_land_sea_file, facility_file, enlarger_weight, ...
     med_index_order)

% load fine obstacle
fine_obs_mat = geotiffread(fine_obs_file);

% load fine sea
fine_land_mat = geotiffread(fine_land_sea_file); % land = 1 and sea = 0
fine_sea_mat = 1 - fine_land_mat;  % land = 0 and sea = 1

% load facility
[med, ~] = geotiffread(facility_file);

% remove the facility 19 if it exists
med(med == 19) = 0;

% get the number of facility
n_facility = sum(sum(med>0));

% get grid size
[n_row, n_col] = size(med); 

% convert the fine obstacle to original size
obs_mat = mapObstacleToGrid(fine_obs_mat, n_row, n_col);

% convert the land grid to original size
land_mat = mapObstacleToGrid(fine_land_mat, n_row, n_col);

% remove the facilities that in the obstacle
med(obs_mat == 1) = 0; 

% remove the facility that in the sea
med(land_mat == 0) = 0; 

% size of cell
size_cell_in_meter = 500 ;% size of cell for original map, default: 500 m
mpc = size_cell_in_meter * 0.000621371; % convert meter to mile

% initialize grid parameter
n_grid_row = n_row * enlarger_weight;
n_grid_col = n_col * enlarger_weight;

% mapping original binary matrix into new grids
obs_grid = mapObstacleToGrid(fine_obs_mat, n_grid_row, n_grid_col);
sea_grid = mapObstacleToGrid(fine_sea_mat, n_grid_row, n_grid_col);
med_grid = mapObstacleToGrid(med, n_grid_row, n_grid_col);

% remove duplicated path
[path] = filter_duplicate_path(path);

% interploation
% calculate the mile per grid according to current grids
mpg_x = mpc * n_row / n_grid_row;
mpg_y = mpc * n_col / n_grid_col;

%% map the path to the grid
% initialize the result grid
flightTimeGrid = ones(n_grid_row, n_grid_col) * 1e+10;
allocationGrid = zeros(n_grid_row, n_grid_col);

% get the row grid and column grid that is not in obstacle or sea
[row_grid, col_grid] = find((obs_grid == 0) & (sea_grid == 0) & ...
                            (med_grid == 0)); 

for i = 1:n_facility
    % get facility index
    facility_index = med_index_order(i, 1);
    
    % get the path for each facility
    path_per_facility = path{1, i};
    
    % map the location in mile to the row and column indices
    path_per_facility(:,1) = path_per_facility(:,1) / mpg_x;
    path_per_facility(:,2) = path_per_facility(:,2) / mpg_y;
    
    % get the boundary of marker's path
    row_lowerBound = floor(min(path_per_facility(:,1)));
    row_upperBound = ceil(max(path_per_facility(:,1)));
    col_lowerBound = floor(min(path_per_facility(:,2)));
    col_upperBound = ceil(max(path_per_facility(:,2)));

    % get the interpolation area for this facility
    row_grid_per_facility = row_grid;
    col_grid_per_facility = col_grid;
    
    % filter the area outside marker's path
    area_index = (row_grid_per_facility <= row_upperBound) & ...
                 (row_grid_per_facility >= row_lowerBound) & ...
                 (col_grid_per_facility <= col_upperBound) & ...
                 (col_grid_per_facility >= col_lowerBound);
    row_grid_per_facility = row_grid_per_facility(area_index, 1);    
    col_grid_per_facility = col_grid_per_facility(area_index, 1);    
    
    % interpolate the path to flight time grid
    F = scatteredInterpolant(path_per_facility(:,1),...
        path_per_facility(:,2), path_per_facility(:,3));
    F.Method = 'linear';  

    % update the facility cluster in each grid inside the convex full
    interpolate_val_vec = max(F(row_grid_per_facility,col_grid_per_facility), 0);
    
    % de-noise: remove the grids whose interpolation values are less than 0s
    row_grid_iter = row_grid_per_facility(interpolate_val_vec >= 0, :);
    col_grid_iter = col_grid_per_facility(interpolate_val_vec >= 0, :);
    interpolate_val_vec = interpolate_val_vec(interpolate_val_vec >= 0, :);
    
    % get interpolate value matrix
    interpolate_val_mat = ones(n_grid_row, n_grid_col) * 1e+11;
    n_grid_area = size(interpolate_val_vec,1);
    for grid_index = 1:n_grid_area
        interpolate_val_mat(row_grid_iter(grid_index), col_grid_iter(grid_index)) = interpolate_val_vec(grid_index);
    end
    
    % update the cluster result
    allocationGrid(interpolate_val_mat <= flightTimeGrid) = facility_index;
    
    % update the shortest flight time in each grid
    flightTimeGrid = min(interpolate_val_mat, flightTimeGrid);
end

% set flight time as 0s in facility location
flightTimeGrid(med_grid > 0) = 0;

% set facility index in facility location
allocationGrid(med_grid>0) = med_grid(med_grid>0);

% remove obstacle from the grid 
[flightTimeGrid] = removeObstacleFromGrid(flightTimeGrid, obs_grid);
[allocationGrid] = removeObstacleFromGrid(allocationGrid, obs_grid);

% remove sea from the grid 
[flightTimeGrid] = removeObstacleFromGrid(flightTimeGrid, sea_grid);
[allocationGrid] = removeObstacleFromGrid(allocationGrid, sea_grid);

% de-noise (clean) the flight time grid
[flightTimeGrid] = cleanNoiseFlightTimeGrid(flightTimeGrid);
[allocationGrid] = cleanNullAllocationGrid(allocationGrid);
[allocationGrid] = cleanNoiseAllocationGrid(allocationGrid);

% remove flight time = 1e+10
flightTimeGrid(flightTimeGrid>1e+5) = max(flightTimeGrid(flightTimeGrid<1e+5));