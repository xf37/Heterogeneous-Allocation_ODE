%%-------------------------------------------------------------------------
% Remove useless markers
% Input:
%                     marker --- the current marker matrix recording 
%                                1. initial location along x-axis in miles,
%                                2. initial location along y-axis in miles,
%                                3. its head angle theta, 
%                                4. its hospital index
%                                5. its marker index
%
%         contributed_marker --- a vector of the marker indices
%                                that contributed to the shortest
%                                allocation time
% Output:
% marker --- only contributed markers left
%--------------------------------------------------------------------------    

function [marker] = updateMarker(marker, contributed_marker)

marker = marker(ismember(marker(:,5), contributed_marker), :);
