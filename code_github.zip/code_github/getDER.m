%%-------------------------------------------------------------------------
% Get the derivative (gradient) of wind speed
% x direction: from top to bottom 
% y direction: from left to right
% Input:
%       um --- m x n wind speed matrix along vertical axis
%              positive direction: from left to right
%       vm --- m x n wind speed matrix along horizontal axis
%              positive direction: from top to bottom
%      mpc --- mile per cell (size of cell)
% Output:
%       ux --- m x n gradient matrix du/dx along vertical axis (top to bottom)
%       uy --- m x n gradient matrix du/dy along horizontal axis (left to right)
%       vx --- m x n gradient matrix dv/dx along vertical axis (top to bottom)
%       vy --- m x n gradient matrix dv/dy along horizontal axis (left to right)
%--------------------------------------------------------------------------
function [ux, uy, vx, vy] = getDER(um, vm, mpc)
[n1,n2] = size(vm);  

%% Initialize output matrix
ux = zeros(n1, n2);
uy = zeros(n1, n2);
vx = zeros(n1, n2);
vy = zeros(n1, n2);

%% Calculate du/dy
uy(:, 1:(n2-1)) = double(um(:, 2:n2)) - double(um(:, 1:(n2-1)));
uy(:, n2) = double(uy(:,n2-1));
uy = uy/mpc;

%% Calculate dv/dy
vy(:, 1:(n2-1)) = double(vm(:, 2:n2)) - double(vm(:, 1:(n2-1)));
vy(:, n2) = double(vy(:,n2-1));
vy = vy/mpc;

%% Calculate du/dx
ux(1:(n1-1), :) = double(um(2:n1, :)) - double(um(1:(n1-1), :));
ux(n1, :) = double(ux(n1-1, :));
ux = ux / mpc;

%% Calculate dv/dx
vx(1:(n1-1), :) = double(vm(2:n1, :)) - double(vm(1:(n1-1), :));
vx(n1, :) = double(vx(n1-1, :));
vx = vx / mpc;