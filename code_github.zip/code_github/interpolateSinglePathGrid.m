%%-------------------------------------------------------------------------
% Map Drone's path to grid and summarize flight time
% Input:
%               Loc --- n x 3 matrix (x, y, theta)
%                 T --- n x 1 flight time vector 
%        n_grid_row --- the number of rows in the output grid
%        n_grid_col --- the number of columns in the output grid
%             n_row --- the number of rows in the original region
%             n_col --- the number of columns in the original region
%               mpc --- mile per cell in the original region
% Output:
%   flightTimeGrid --- the shortest flight time in each grid
%      clusterGrid --- the facility index where the best marker (with
%                      shortest flight time) comes from
%--------------------------------------------------------------------------

function [flightTimeGrid] = interpolateSinglePathGrid(Loc, T, n_grid_row, n_grid_col, n_row, n_col, mpc)

%% calculate the mile per grid according to current grids
mpg_x = mpc * n_row / n_grid_row;
mpg_y = mpc * n_col / n_grid_col;

%% map the path to the grid 
% interpolate the path to flight time grid
F = scatteredInterpolant(Loc(:,1)/mpg_x, Loc(:,2)/mpg_y, T);
[row_grid, col_grid] = meshgrid(1:1:n_grid_row, 1:1:n_grid_col);
F.Method = 'linear';
flightTimeGrid = (F(row_grid,col_grid))';
