%%-------------------------------------------------------------------------
% Delete redundant markers based on path Interpolation
% Input:
%            marker --- the n_marker x 6 matrix recording 
%                       1. initial location along row (vertical)-axis in miles,
%                       2. initial location along column (horizonal)-axis in miles,
%                       3. its head angle theta, 
%                       4. its hospital index
%                       5. its marker index
%                       6. the flight time
%               mpc --- mile per cell (size of cell)
%           obs_mat --- bineary obstacle matrix
% Output:
%            marker --- the updated marker matrix where the markers
%                       dropping in the obstacle area are deleted
%--------------------------------------------------------------------------

function [marker] = removeObstacleMarker(marker, mpc, obs_mat)

%% get parameters
% get the dimensions
[n_row, n_col] = size(obs_mat);

% get the number of markers
n_marker = size(marker, 1);

% map the location in mile to row and column indices
row_ind = ceil(marker(:, 1) / mpc);
col_ind = ceil(marker(:, 2) / mpc);

%% remove the markers dropping in the obstacle
keep_marker = ones(n_marker, 1); % create a binary vector recording whether to keep marker

% varify whether marker is located in the obstacle area
for i = 1:n_marker
    if (row_ind(i) > n_row) || (col_ind(i) > n_col)
        keep_marker(i) = 0;
    elseif obs_mat(row_ind(i), col_ind(i)) ==  1
        keep_marker(i) = 0;
    end
end

% update the marker
marker = marker(keep_marker == 1, :);
