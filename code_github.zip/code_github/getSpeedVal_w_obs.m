%%-------------------------------------------------------------------------
% Get speed, its gradient, and binary drone area in given location and time
% Input:
%          uMat ---- m x n wind speed matrix along vertical axis
%          vMat ---- m x n wind speed matrix along horizontal axis
%         uxMat ---- m x n gradient matrix du/dx for vertical wind
%         uyMat ---- m x n gradient matrix du/dy for vertical wind
%         vxMat ---- m x n gradient matrix dv/dx for horizontal wind
%         vyMat ---- m x n gradient matrix dv/dy for horizontal wind
%     gxFineMat ---- m x n gradient matrix dg/dx for indictor function
%     gyFineMat ---- m x n gradient matrix dg/dy for indictor function
%             x ---- current location on vertical axis (mile)
%             y ---- current location on horizontal axis (mile)
%           mpc ---- mile per cell (size of cell)
%      fine_mpc ---- mile per fined cell (size of fined cell)
% fineDroneArea ---- am x an fine binary matrix recoding whether drone can fly
% Output:
%             u ---- wind speend along vertical axis at (x,y)
%             v ---- wind speend along horizontal axis at (x,y)
%            ux ---- gradient du/dx of wind speed at (x,y)
%            uy ---- gradient du/dy of wind speed at (x,y)
%            vx ---- gradient dv/dx of wind speed at (x,y)
%            vy ---- gradient dv/dy of wind speed at (x,y)
%            gx ---- gradient dg/dx of indicator function at (x,y)
%            gy ---- gradient dg/dy of indicator function at (x,y)
%        droneA ---- whether or not drone could fly
%-------------------------------------------------------------------------
function [u, v, ux, uy, vx, vy, gx, gy, droneA] = getSpeedVal_w_obs(uMat, ...
    vMat, uxMat, uyMat, vxMat, vyMat, gxFineMat, gyFineMat, x, y, mpc, ...
    fine_mpc, fineDroneArea)

% Get grid size
[nx, ny] = size(uMat);

% Get fined grid size
[nxFine, nyFine] = size(gxFineMat);

% Convert location to row index and column index
[rowInd, colInd] = getIndexOfMatrix(x, y, mpc, nx, ny);

% Convert location to fined row index and column index
[fineRowInd, fineColInd] = getIndexOfMatrix(x, y, fine_mpc, nxFine, nyFine);

% Get wind speed
u = uMat(rowInd, colInd);
v = vMat(rowInd, colInd);

% Get gradient of wind speed
ux = double(uxMat(rowInd, colInd));
uy = double(uyMat(rowInd, colInd));
vx = double(vxMat(rowInd, colInd));
vy = double(vyMat(rowInd, colInd));
gx = double(gxFineMat(fineRowInd, fineColInd));
gy = double(gyFineMat(fineRowInd, fineColInd));

% Identify whether it is drone Area
droneA = double(fineDroneArea(fineRowInd, fineColInd));