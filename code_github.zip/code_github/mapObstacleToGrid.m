%%-------------------------------------------------------------------------
% Mapping original obstacle/sea binary matrix into new matrix with different
% grid size
% Input:
%        binary_mat --- n x m binary matrix
%        n_grid_row --- the number of rows in the output grid
%        n_grid_col --- the number of columns in the output grid
% Output:
%       binary_grid --- n_grid_row x n_grid_col binary matrix in new grid
%--------------------------------------------------------------------------
function [binary_grid] = mapObstacleToGrid(binary_mat, n_grid_row, n_grid_col)

%% get the size of the matrix
[n_row, n_col] = size(binary_mat);

%% initialize the new binary grid
binary_grid = zeros(n_grid_row, n_grid_col);

%% mapping original binary matrix to the new grid
for i = 1:n_grid_row
    for j = 1:n_grid_col
        % map new grid index to original matrix index (larger than 1)
        original_row_ind = max(1, floor(n_row * i / n_grid_row)); 
        original_col_ind = max(1, floor(n_col * j / n_grid_col));
        binary_grid(i, j) = binary_mat(original_row_ind, original_col_ind);
    end
end
        