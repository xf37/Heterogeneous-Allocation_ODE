function [allocate_mat] = allocationMatCalculation(path, ...
    fine_obs_file, fine_land_sea_file, facility_file, enlarger_weight)

% get the number of facilities
n_facility = size(path,2); 

% load fine obstacle
fine_obs_mat = geotiffread(fine_obs_file);

% load fine sea
fine_land_mat = geotiffread(fine_land_sea_file); % land = 1 and sea = 0
fine_sea_mat = 1 - fine_land_mat;  % land = 0 and sea = 1

% load facility
[med, ~] = geotiffread(facility_file);

% get grid size
[n_row, n_col] = size(med); 

% size of cell
size_cell_in_meter = 500 ;% size of cell for original map, default: 500 m
mpc = size_cell_in_meter * 0.000621371; % convert meter to mile

% calculate the mile per grid according to current grids
mpg = mpc / enlarger_weight;

% initialize grid parameter
n_grid_row = n_row * enlarger_weight;
n_grid_col = n_col * enlarger_weight;

% mapping original binary matrix into new grids
fine_obs_grid = mapObstacleToGrid(fine_obs_mat, n_grid_row, n_grid_col);
fine_sea_grid = mapObstacleToGrid(fine_sea_mat, n_grid_row, n_grid_col);

% convert med location to grid
med_grid = mapObstacleToGrid(med, n_grid_row, n_grid_col);

% remove the facilities that in the obstacle
med_grid(fine_obs_grid == 1) = 0; 

% remove the facility that in the sea
med_grid(fine_sea_grid == 1) = 0; 

% record hospital index
loc_binary = (med_grid == 1);

% initialize the time matrix
inf_time = 1e+10;
time_mat = ones(n_grid_row, n_grid_col) * inf_time;
time_mat(fine_sea_grid == 1) = 0; % remove sea
time_mat(fine_obs_grid == 1) = 0; % remove obstacle
time_mat(loc_binary) = 0; % set the shortest time as 0 for facility location

% initialize the allocation matrix
allocate_mat = zeros(n_grid_row, n_grid_col);
allocate_mat(fine_sea_grid == 1) = 1e+10;
allocate_mat(fine_obs_grid == 1) = 1e+10;

for i = 1:n_facility
        
    % get marker's path
    facility_path = path{1,i};
    marker_time = facility_path(:,3); % time along drone's path    
    marker_loc = facility_path(:,1:2); % marker's location (x,y) along the path
    
    % map path matrix to grid matrix
    grid_mat = convertLocToGrid(marker_loc, mpg, n_grid_row, n_grid_col);
    
    % update the shortest time in each grid
    for j = 1:size(grid_mat, 1)
        if time_mat(grid_mat(j,1), grid_mat(j,2)) > marker_time(j,1)
            time_mat(grid_mat(j,1), grid_mat(j,2)) = marker_time(j,1);
            allocate_mat(grid_mat(j,1), grid_mat(j,2)) = i;
        end
    end

end

% remove 0s in allocation mat
allocate_null_binary = (allocate_mat == 0);
[null_row_ind, null_col_ind] = find(allocate_null_binary);

for i = 1:size(null_row_ind,1)
    null_row = null_row_ind(i);
    null_col = null_col_ind(i);
    
    if (allocate_mat(null_row-1, null_col)>=1)&&(allocate_mat(null_row-1, null_col)<=n_facility)
        facility_index = allocate_mat(null_row-1, null_col);
    elseif (allocate_mat(null_row, null_col-1)>=1)&&(allocate_mat(null_row, null_col-1)<=n_facility)
        facility_index = allocate_mat(null_row, null_col-1);
    elseif (allocate_mat(null_row+1, null_col)>=1)&&(allocate_mat(null_row+1, null_col)<=n_facility)
        facility_index = allocate_mat(null_row+1, null_col);
    elseif (allocate_mat(null_row, null_col+1)>=1)&&(allocate_mat(null_row, null_col+1)<=n_facility)
        facility_index = allocate_mat(null_row, null_col+1);
    elseif (allocate_mat(null_row-1, null_col-1)>=1)&&(allocate_mat(null_row-1, null_col-1)<=n_facility)
        facility_index = allocate_mat(null_row-1, null_col-1);
    elseif (allocate_mat(null_row-1, null_col+1)>=1)&&(allocate_mat(null_row-1, null_col+1)<=n_facility)
        facility_index = allocate_mat(null_row-1, null_col+1);
    elseif (allocate_mat(null_row+1, null_col-1)>=1)&&(allocate_mat(null_row+1, null_col-1)<=n_facility)
        facility_index = allocate_mat(null_row+1, null_col-1);
    elseif (allocate_mat(null_row+1, null_col+1)>=1)&&(allocate_mat(null_row+1, null_col+1)<=n_facility)
        facility_index = allocate_mat(null_row+1, null_col+1);
    end
    
    allocate_mat(null_row, null_col) = facility_index;
end