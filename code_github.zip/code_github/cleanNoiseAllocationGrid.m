% remove flight time > 1e+5
function [allocationGrid] = cleanNoiseAllocationGrid(allocationGrid)

% get grid size
[n_row_grid, n_col_grid] = size(allocationGrid);

% find no-nan index
[row_ind, col_ind] = find(~isnan(allocationGrid));

% filter the boundary index
row_ind = row_ind((col_ind > 1) & (col_ind < n_col_grid));
col_ind = col_ind((col_ind > 1) & (col_ind < n_col_grid));
col_ind = col_ind((row_ind > 1) & (row_ind < n_row_grid));
row_ind = row_ind((row_ind > 1) & (row_ind < n_row_grid));

% clean by 5 iterations
for iter = 1:5
    
    % for loop all allocation index
    for i = 1:size(row_ind, 1)
        % get the allocation result in that index
        allocation_row_ind = row_ind(i);
        allocation_col_ind = col_ind(i);

        % get the around allocation results
        around1 = allocationGrid(allocation_row_ind-1, allocation_col_ind-1);
        around2 = allocationGrid(allocation_row_ind-1, allocation_col_ind);
        around3 = allocationGrid(allocation_row_ind-1, allocation_col_ind+1);
        around4 = allocationGrid(allocation_row_ind, allocation_col_ind-1);
        around5 = allocationGrid(allocation_row_ind, allocation_col_ind+1);
        around6 = allocationGrid(allocation_row_ind+1, allocation_col_ind-1);
        around7 = allocationGrid(allocation_row_ind+1, allocation_col_ind);
        around8 = allocationGrid(allocation_row_ind+1, allocation_col_ind+1);
        around_vec = [around1 around2 around3 around4 around5 around6 around7 around8];

        % remove NaN
        around_vec = around_vec(around_vec>0);

        % get the frequency of each facility
        [freq_facility, unique_facility] = hist(around_vec, unique(around_vec)); 

        % get the facility index if its frequency >= 5
        most_freq_facility = unique_facility(freq_facility >= 5);
        
        % get the facility index if it is all around
        all_around_facility = unique_facility(freq_facility == length(around_vec));

        % update allocation result for de-noising
        if length(most_freq_facility) == 1
            allocationGrid(allocation_row_ind, allocation_col_ind) = most_freq_facility(1,1);
        elseif length(all_around_facility) == 1
            allocationGrid(allocation_row_ind, allocation_col_ind) = all_around_facility(1,1);      
        end
    end
end