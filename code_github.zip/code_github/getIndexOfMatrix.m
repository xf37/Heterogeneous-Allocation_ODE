%%-------------------------------------------------------------------------
% Get the location index
% Input:
%     xLoc --- location along x axis (rows in the matrix)
%     yLoc --- location along y axis (columns in the matrix)
%      mpc --- mile per cell (size of cell)
%       nx --- the maxium row in the grid map
%       ny --- the maxium column in the grid map
% Output:
%     xInd --- grid index along x axis (the row index in the matrix)
%     yInd --- grid index along y axis (the column index in the matrix)
%--------------------------------------------------------------------------
function [xInd, yInd] = getIndexOfMatrix(xLoc, yLoc, mpc, nx, ny)
% get row index in the range of [1, nx]
xInd = min(max(floor(xLoc/mpc), 1), nx);

% get column index in the range of [1, ny]
yInd = min(max(floor(yLoc/mpc), 1), ny);