%%-------------------------------------------------------------------------
% Map Drone's path to grid and summarize flight time
% Input:
%              path --- 1 x n_facility cell
%                       each element is n x 3 matrix recording the unique 
%                       location and flight time matrix for each facility
%        n_grid_row --- the number of rows in the output grid
%        n_grid_col --- the number of columns in the output grid
%             n_row --- the number of rows in the original region
%             n_col --- the number of columns in the original region
%          obs_grid --- n_grid_row x n_grid_col binary matrix recoding
%                       obstacle. 1: obstacle; 0: non-obstacle
%          sea_grid --- n_grid_row x n_grid_col binary matrix recoding sea;
%                       1: sea; 0: land
%          med_grid --- n_grid_row x n_grid_col binary matrix recoding
%                       facility. 1: facility; 0: land
%               mpc --- mile per cell in the original region
% Output:
%          path_all --- n x 3 matrix recording the unique 
%                       location and flight time matrix for all facilities
%--------------------------------------------------------------------------

function [path_all] = removePathAcrossFacility(path)

% initialize the final path result
path_all = [];

% combine all path together
path_all_temp = cell2mat(path');

% round decimal number of locations to 0 places
path_all_temp = roundn(path_all_temp, 0);

% get the range of row and column
row_min = min(path_all_temp(:,1));
row_max = max(path_all_temp(:,1));
col_min = min(path_all_temp(:,2));
col_max = max(path_all_temp(:,2));

% split the area into small areas
number_split_each_row_col = 10;

% get the range of row and column in each small area
row_range_small_area = (row_max - row_min) / number_split_each_row_col;
col_range_small_area = (col_max - col_min) / number_split_each_row_col;

for i = 1:number_split_each_row_col
    % get the row range in each small area
    row_min_small_area = row_range_small_area * (i-1) + row_min;
    row_max_small_area = row_range_small_area * i + row_min;
    
    % get the path inside row range
    path_iteration = path_all_temp((path_all_temp(:,1) <= row_max_small_area) & (path_all_temp(:,1) >= row_min_small_area),:);
    
    for j = 1:number_split_each_row_col
        % get the row range in each small area
        col_min_small_area = col_range_small_area * (j-1) + col_min;
        col_max_small_area = col_range_small_area * j + col_min;
        path_small_area = path_iteration((path_iteration(:,2) <= col_max_small_area) & (path_iteration(:,2) >=col_min_small_area),:);
        
        % sort and filter the duplicated path
        [~,idx] = sort(path_small_area(:, 3));
        path_small_area = path_small_area(idx, :);  
    
        % get the unique locations 
        % (the duplicated locations with larger flight time are removed)
        [~, idu] = unique(path_small_area(:, 1:2), 'rows');
        path_small_area = path_small_area(idu, :);
        
        % combine path from small areas
        path_all = [path_all; path_small_area];
    end
end