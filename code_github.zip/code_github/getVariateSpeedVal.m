%%-------------------------------------------------------------------------
% Get speed, its gradient, and binary drone area in given location and time
% Input:
%      uCell ---- 1 x T cells (cell: m x n wind speed matrix along x axis across T time periods)
%      vCell ---- 1 x T cells (cell: m x n wind speed matrix along y axis across T time periods)
%     uxCell ---- 1 x number of grid cell,
%                 where each element is m x n gradient matrix du/dx for vertical wind
%     uyCell ---- 1 x number of grid cell,
%                 where each element is m x n gradient matrix du/dy for vertical wind
%     vxCell ---- 1 x number of grid cell,
%                 where each element is m x n gradient matrix dv/dx for horizontal wind
%     vyCell ---- 1 x number of grid cell,
%                 where each element is m x n gradient matrix dv/dy for horizontal wind
%          x ---- current location on x axis (mile)
%          y ---- current location on y axis (mile)
%          t ---- current time
%        mpc ---- mile per cell (size of cell, default: 98.60774 m = 0.061272 mile)
%        spg ---- seconds per time grid
%  droneArea ---- m x n binary matrix recoding whether drone can fly
% Output:
%          u ---- wind speend along x axis at (x,y,t)
%          v ---- wind speend along y axis at (x,y,t)
%         ux ---- partial graident of wind speend along x axis at (x,y,t) (du/dx)
%         uy ---- partial graident of wind speend along x axis at (x,y,t) (du/dy)
%         vx ---- partial graident of wind speend along y axis at (x,y,t) (dv/dx)
%         vy ---- partial graident of wind speend along y axis at (x,y,t) (dv/dy)
%     droneA ---- whether or not drone could fly
%-------------------------------------------------------------------------

function [u,v,ux,uy,vx,vy,droneA] = getVariateSpeedVal(uCell, vCell, uxCell, uyCell, vxCell, vyCell, x, y, t, mpc, spg, droneArea)

% Get wind speed
[uMat, vMat] = getVariateDiscreteWindSpeed(uCell, vCell, spg, t);

% Get gradient of wind speed
[uxMat, uyMat] = getVariateDiscreteWindSpeed(uxCell, uyCell, spg, t);
[vxMat, vyMat] = getVariateDiscreteWindSpeed(vxCell, vyCell, spg, t);

% Get grid size
[nx, ny] = size(uMat);

% Convert location to row index and column index
[xInd, yInd] = getIndexOfMatrix(x, y, mpc, nx, ny);

% Get wind speed and its gradient in the given grid
u = uMat(xInd, yInd);
v = vMat(xInd, yInd);
ux = uxMat(xInd, yInd);
vx = vxMat(xInd, yInd);
uy = uyMat(xInd, yInd);
vy = vyMat(xInd, yInd);

% Identify whether it is drone Area
droneA = droneArea(xInd, yInd);