%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% main function for calculating flight time and allocation
% ODE-based main function calculating the hetergeneous Voronoi Diagram 
clear all
clc
close all
tic

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Case 1: time = 9
%% Load files
% Load the directory for facility matrix
facility_file = '~\data\Recent\Facility\id_facility_24_9.tif';

% Load the directory for wind speed matrix
wind_u_file = '~\data\Recent\Wind\U_9_1_Resample.tif';
wind_v_file = '~\data\Recent\Wind\V_9_1_Resample.tif';

% Load the directory for fined land-sea matrix
fine_land_sea_file =  '~\data\Recent\Sea_Obstacles\fine_land_sea.tif';

% Load the directory for land-sea matrix
land_sea_file =  '~\data\Recent\Sea_Obstacles\land_sea.tif';
% land_sea_file =  '~\data\Recent\Sea_Obstacles\land_sea.tif';

% Load the directory for fined obstacle matrix
fine_obs_file =  '~\data\Recent\Sea_Obstacles\fine_obs_24_9.tif';

% Load the directory for obstacle matrix
obs_file =  '~\data\Recent\Sea_Obstacles\obs_24_9.tif';

% The directory for saving path
path_file = '~\new_result\multi_generator\path_9.mat';

% The directory for saving flight time matrix
flightTimeMat_file = '~\new_result\multi_generator\flightTimeMat_9.mat';

% The txt directory for saving flight time matrix
flightTimeMat_txt_file = '~\new_result\multi_generator\flightTimeMat_9.txt';

% The directory for saving allocation matrix
allocationMat_file = '~\new_result\multi_generator\allocationMat_9.mat';

% The txt directory for saving allocation matrix
allocationMat_txt_file = '~\new_result\multi_generator\allocationMat_9.txt';

% The directory for saving facility index
facilityIndex_file = '~\new_result\multi_generator\med_index_order_9.mat';

% The directory for save figure
figure_file = '~\new_result\multi_generator\figure\flightTime_9.pdf';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% set up parameters
% set the number of markers per facility
n_angle = 1080;

% set the flight time period
t_period = 1200;

%% calculate the path
[path, med_index_order] = pathCalculation(wind_u_file, wind_v_file, ...
    obs_file, fine_obs_file, land_sea_file, ...
    facility_file, path_file, n_angle, t_period);

%% Interpolate the path
% initialize grid parameter
enlarger_weight = 4;

% calculate the flight time interpolation
[flightTimeGrid, allocationGrid] = flightTimeInterpolate(path, ...
    fine_obs_file, fine_land_sea_file, facility_file, ...
    enlarger_weight, med_index_order);

%% Path visualization
plotFlightTimeGrid(flightTimeGrid, figure_file);

%% cluster visualization
figure;
imagesc(allocationGrid);
colormap('jet')
% colorbar;

%% save results
save(flightTimeMat_file,'flightTimeGrid');
dlmwrite(flightTimeMat_txt_file, flightTimeGrid);
save(allocationMat_file,'allocationGrid');
dlmwrite(allocationMat_txt_file, allocationGrid);
save(facilityIndex_file,'med_index_order');

toc