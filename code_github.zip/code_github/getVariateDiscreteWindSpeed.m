%%-------------------------------------------------------------------------
% Get speed, its gradient, and binary drone area in given location and time
% Input:
%      uCell ---- 1 x T cells (cell: m x n wind speed matrix along column axis across T time periods)
%      vCell ---- 1 x T cells (cell: m x n wind speed matrix along row axis across T time periods)
%          t ---- current time
%        spg ---- seconds per time grid
% Output:
%       uMat ---- m x n wind speed matrix along x axis at time t
%       vMat ---- m x n wind speed matrix along y axis at time t
%-------------------------------------------------------------------------
function [uMat, vMat] = getVariateDiscreteWindSpeed(uCell, vCell, spg, t)
% Get the maximum time 
T = length(uCell);

% Get the neighbourhood time grid
grid_ind = round(t/spg);

if grid_ind == 0
    uMat = uCell{1,1};
    vMat = vCell{1,1};
elseif grid_ind >= T
    uMat = uCell{1,T};
    vMat = vCell{1,T};
else
    uMat = uCell{1,grid_ind};
    vMat = vCell{1,grid_ind};
end