%%-------------------------------------------------------------------------
% Calculate the marker's flight path 
% Input:
%       wind_u_file --- the directory for wind speed matrix u
%       wind_v_file --- the directory for wind speed matrix v
%          obs_file --- the directory for obstacle matrix
%     fine_obs_file --- the directory for fined obstacle matrix
%     land_sea_file --- the directory for land and sea matrix
%     facility_file --- the directory for facility matrix
%         path_file --- the directory for saving path
%           n_angle --- number of markers per facility
%          t_period --- flight time period for each marker
% Output:
%              path --- 1 x n_facility cell
%                       each element is n x 3 matrix recording the unique 
%                       location and flight time matrix for each facility
%   med_index_order --- n_facility x 1 recording facility indices for each
%                       path
%--------------------------------------------------------------------------
function [path, med_index_order] = pathCalculation(wind_u_file, wind_v_file, ...
    obs_file, fine_obs_file, land_sea_file, facility_file, path_file, ...
    n_angle, t_period)

%% Load inland wind speed matrix from fined map (area with absolute speed more than 10^3 is the sea)
% get wind speed along horizontal axis (mile/hour) from left to right (westly)
[colSpeed, ~] = geotiffread(wind_u_file);

% get wind speed along vertical axis (mile/hour) from bottom to top (southly)
[rowSpeed, ~] = geotiffread(wind_v_file);

% reverse the vertical wind so that the positive direction is from top to bottom
rowSpeed = -rowSpeed;

% Convert wind speed from mile/hour to mile/sec
rowSpeed = rowSpeed / 3600;
colSpeed = colSpeed / 3600;

% Change wind
weight = 1;
rowSpeed = rowSpeed * weight;
colSpeed = colSpeed * weight;

%% Load obstacle binary matrix (obstacle = 1 and non-obstacle = 0)
obs_mat = geotiffread(obs_file);

%% Load fine obstacle binary matrix (obstacle = 1 and non-obstacle = 0)
fine_obs_mat = geotiffread(fine_obs_file);

%% Load land-sea binary matrix 
land_mat = geotiffread(land_sea_file); % land = 1 and sea = 0

%% Load facility binary matrix (facility = 1 and non-facility = 0)
[med, ~] = geotiffread(facility_file);

% remove the facility 19 if it exists
med(med == 19) = 0; 

% remove the facilities that in the obstacle
med(obs_mat == 1) = 0; 

% remove the facility that in the sea
med(land_mat == 0) = 0; 

% record hospital index
n_facility = sum(sum(med > 0));
med_index_order = zeros(n_facility, 1);
med_row_ind = zeros(n_facility, 1);
med_col_ind = zeros(n_facility, 1);
ind = 1;

for i = 1:max(max(med))
    if sum(sum(med == i)) > 0
        [med_row_ind(ind, 1), med_col_ind(ind, 1)] = find(med == i);
        med_index_order(ind, 1) = i;
        ind = ind + 1;  
    end
end

%% Set the global parameter
% size of cell
size_cell_in_meter = 500 ;% size of cell for original map, default: 500 m
mpc = size_cell_in_meter * 0.000621371; % convert meter to mile

% size of fine cell
size_fine_cell_in_meter = 100 ;% size of cell for fine map: 100 m
fine_mpc = size_fine_cell_in_meter * 0.000621371; % convert meter to mile

% drone speed, mile/sec
droneSpeed = 50 / 3600;

% fine binary matrix, whether drone can fly (0: no-drone area)
fineDroneArea = 1 - fine_obs_mat;

%% Initialize parameters
% number of facilities
n_facility = length(med_row_ind);

%% Initialize markers
% marker: n_marker x 5 matrix
%         each row: (vertical_location, horizontal_location, theta, hospital index, marker index)
[marker] = initializeMarker(n_angle, med_row_ind, med_col_ind, mpc);

%% Initialize flight time (marker's path) from each facility
path = cell(1, n_facility);

%% Calculate the gradient matrix for wind speed
% colSpeedXMat: the gradient martix of u along vertical axis (top to bottom)
% colSpeedYMat: the gradient matrix of u along horizontal axis (left to right)
% rowSpeedXMat: the gradient martix of v along vertical axis (top to bottom)
% rowSpeedYMat: the gradient matrix of v along horizontal axis (left to right)
[colSpeedXMat, colSpeedYMat, rowSpeedXMat, rowSpeedYMat] = getDER(colSpeed, rowSpeed, mpc);

%% Calculate the gradient matrix for spatial indicaor 
% gxFineMat: the fined gradient martix of g along vertical axis (top to bottom)
% gyFineMat: the fined gradient matrix of g along horizontal axis (left to right)
[gxFineMat, gyFineMat] = getObsDER(fineDroneArea, fine_mpc);

%% Initialize time period
t_start = 0;
t_end = t_start + t_period;
TSPAN = t_start:1:t_end;

%% Solve ODE to get the shortest path from each facility without iteration
% update_marker is n x 6 matrix, which records the latest location
% (x, y, theta, facility_index, marker_index, flight_time)
update_marker = [marker zeros(size(marker, 1), 1)];

for i = 1:size(update_marker, 1)
    % get facility index
    facility_index = update_marker(i,4);
    
    % get marker's current position and head angle
    IC = update_marker(i,1:3);

    % calculate marker's path
    if facility_index == 31
        [T, Loc] = ode45(@(t,var) ode_w_obs(var, rowSpeed, colSpeed, ...
            rowSpeedXMat, rowSpeedYMat, colSpeedXMat, colSpeedYMat, ...
            gxFineMat, gyFineMat, fineDroneArea, droneSpeed, mpc, ...
            fine_mpc), 0:1:1500, IC); 
            % solve Euler-Lagrange equation to get Drone's path        
    else
        [T, Loc] = ode45(@(t,var) ode_w_obs(var, rowSpeed, colSpeed, ...
            rowSpeedXMat, rowSpeedYMat, colSpeedXMat, colSpeedYMat, ...
            gxFineMat, gyFineMat, fineDroneArea, droneSpeed, mpc, ...
            fine_mpc), TSPAN, IC); 
            % solve Euler-Lagrange equation to get Drone's path
    end

    % update marker (add one more column (6-th column) recording flight time)
    update_marker(i, :) = [Loc(end, :) update_marker(i, 4:5) T(end, :)];

    % update marker's path (flight time) from each facility
    path{1, facility_index} = [path{1, facility_index}; Loc(:, 1:2) T];   
end

% save path
save(path_file,'path');