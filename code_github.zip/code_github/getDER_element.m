%%-------------------------------------------------------------------------
% Get the derivative (gradient) of wind speed for specific index
% Input:
%       um --- m x n wind speed matrix along x axis
%       vm --- m x n wind speed matrix along y axis
%      mpc --- mile per cell (size of cell)
%   rowInd --- row index, the x index for specific point
%   colInd --- column index, the y index for specific point
% Output:
%       ux --- gradient du/dx for the point (rowInd, colInd)
%       uy --- gradient du/dy for the point (rowInd, colInd)
%       vx --- gradient dv/dx for the point (rowInd, colInd)
%       vy --- gradient dv/dy for the point (rowInd, colInd)
%--------------------------------------------------------------------------
function [ux, uy, vx, vy] = getDER_element(um, vm, mpc, rowInd, colInd)
[n1,n2] = size(vm);  

if xInd == n1:
    ux = um()
end
    

%% Initialize output matrix
ux = zeros(n1, n2);
uy = zeros(n1, n2);
vx = zeros(n1, n2);
vy = zeros(n1, n2);

%% Calculate du/dx
ux(:, 1:(n2-1)) = um(:, 2:n2) - um(:, 1:(n2-1));
ux(:, n2) = ux(:,n2-1);
ux = ux/mpc;

%% Calculate dv/dx
vx(:, 1:(n2-1)) = vm(:, 2:n2) - vm(:, 1:(n2-1));
vx(:, n2) = vx(:,n2-1);
vx = vx/mpc;

%% Calculate du/dy
uy(1:(n1-1), :) = um(2:n1, :) - um(1:(n1-1), :);
uy(n1, :) = uy(n1-1, :);
uy = uy / mpc;

%% Calculate dv/dy
vy(1:(n1-1), :) = vm(2:n1, :) - vm(1:(n1-1), :);
vy(n1, :) = vy(n1-1, :);
vy = vy / mpc;