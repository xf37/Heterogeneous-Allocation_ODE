%%-------------------------------------------------------------------------
% Delete redundant markers based on path Interpolation
% Input:
%            marker --- the n_marker x 6 matrix recording 
%                       1. initial location along row (vertical)-axis in miles,
%                       2. initial location along column (horizonal)-axis in miles,
%                       3. its head angle theta, 
%                       4. its hospital index
%                       5. its marker index
%                       6. the flight time
%               mpc --- mile per cell (size of cell)
%             n_row --- the number of rows in the region
%             n_col --- the number of columns in the region
% Output:
%            marker --- the updated marker matrix where the markers hitting
%                       the boundary are deleted
%--------------------------------------------------------------------------

function [marker] = removeBoundaryMarker(marker, mpc, n_row, n_col)

% get the boundary of the region (in miles)
x_max = n_row * mpc;
y_max = n_col * mpc;

% remove the markers hitting the boundary
marker = marker((marker(:, 1) <= x_max) & (marker(:, 1) >= 0) & (marker(:, 2) <= y_max) & (marker(:, 2) >= 0), :);
