%%-------------------------------------------------------------------------
% Remove duplicated location in the path
% Input:
%      path --- flight time cell
%               each element is a n x 3 matrix recording the location (x, y) in mile 
%               and the flight time t of the markers coming from each facility
% Output:
%      path --- flight time cell, where the duplicated location is removed
%--------------------------------------------------------------------------
function [path] = filter_duplicate_path(path)

% get the number of facilities
n_facility = size(path, 2);

% round decimal number and remove duplicated path
for i = 1:n_facility
    path_one_facility = path{1, i};
    
    % round decimal number of locations to 1 places
    path_one_facility(:, 1:2) = roundn(path_one_facility(:, 1:2), -1);
    
    % sort matrix (acsending) by flight time
    [~,idx] = sort(path_one_facility(:, 3));
    path_one_facility = path_one_facility(idx, :);  
    
    % get the unique locations 
    % (the duplicated locations with larger flight time are removed)
    [~, idu] = unique(path_one_facility(:, 1:2), 'rows');
    path_one_facility = path_one_facility(idu, :);
    
    % update the path cell
    path{1, i} = path_one_facility;
end