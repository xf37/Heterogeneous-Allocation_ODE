%%-------------------------------------------------------------------------
% Map Drone's path to grid and update the allocation cluster
%           marker --- the current marker matrix recording 
%                                1. initial location along x-axis in miles,
%                                2. initial location along y-axis in miles,
%                                3. its head angle theta, 
%                                4. its hospital index
%                                5. its marker index
%          Loc_res --- 1 x n_marker cell recroding drone's path and head angle
%            T_res --- 1 x n_marker cell recroding related drone's fligt time 
%               nx --- number of rows in the map
%               ny --- number of columns in the map
%    prev_time_mat --- the shortest time each grid in the previous iteration
% prev_cluster_mat --- the shortest time each grid in the previous iteration
%              mpc --- mile per cell (size of cell)
% Output:
%      cluster_mat --- the updated allocation cluster in each grid
%         time_mat --- the updated shortest time in each grid
%--------------------------------------------------------------------------

function [cluster_mat, time_mat] = mapPathToCluster(marker, Loc_res, T_res, nx, ny, mpc, prev_cluster_mat, prev_time_mat)

% define the matrix for the whole map with nx rows and ny columns
cluster_mat = prev_cluster_mat;
time_mat = prev_time_mat;

% get the number of markers
n_marker = size(Loc_res, 2);

for i = 1:n_marker
    
    % get hospital index
    hospital_index = marker(i,4); 
    
    % get marker's path
    marker_path = Loc_res{1, i}; % (x,y,theta) along drone's path
    marker_time = T_res{1, i}; % time along drone's path    
    marker_loc = marker_path(:,1:2); % marker's location (x,y) along the path
    
    % map path matrix to grid matrix
    grid_mat = convertLocToGrid(marker_loc, mpc, nx, ny);
    
    % update the shortest time in each grid
    for j = 1:size(grid_mat, 1)
        if time_mat(grid_mat(j,1), grid_mat(j,2)) > marker_time(j,1)
            time_mat(grid_mat(j,1), grid_mat(j,2)) = marker_time(j,1);
            cluster_mat(grid_mat(j,1), grid_mat(j,2)) = hospital_index;
        end
    end
end