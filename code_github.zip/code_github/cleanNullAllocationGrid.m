% remove flight time > 1e+5
function [allocationGrid] = cleanNullAllocationGrid(allocationGrid)

% remove 0s in allocation mat
flightTimeGrid_noise_binary = (allocationGrid == 0);
[noise_row_ind, noise_col_ind] = find(flightTimeGrid_noise_binary);

for i = 1:size(noise_row_ind,1)
    noise_row = noise_row_ind(i);
    noise = noise_col_ind(i);
    
    if allocationGrid(noise_row-1, noise) > 0
        facility_index = allocationGrid(noise_row-1, noise);
    elseif allocationGrid(noise_row, noise-1) > 0
        facility_index = allocationGrid(noise_row, noise-1);
    elseif allocationGrid(noise_row+1, noise)  > 0
        facility_index = allocationGrid(noise_row+1, noise);
    elseif allocationGrid(noise_row, noise+1)  > 0
        facility_index = allocationGrid(noise_row, noise+1);
    elseif allocationGrid(noise_row-1, noise-1) > 0
        facility_index = allocationGrid(noise_row-1, noise-1);
    elseif allocationGrid(noise_row-1, noise+1) > 0
        facility_index = allocationGrid(noise_row-1, noise+1);
    elseif allocationGrid(noise_row+1, noise-1)  > 0
        facility_index = allocationGrid(noise_row+1, noise-1);
    elseif allocationGrid(noise_row+1, noise+1)  > 0
        facility_index = allocationGrid(noise_row+1, noise+1);
    end
    
    allocationGrid(noise_row, noise) = facility_index;
end