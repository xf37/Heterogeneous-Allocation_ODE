%%-------------------------------------------------------------------------
% Convert the location mat into index mat (convert mile mat -> grid mat)
% Input:
%  loc_mat --- the location matrix using mile (xLoc, yLoc)
%      mpc --- mile per cell (size of cell)
%       nx --- the maxium row in the grid map
%       ny --- the maxium column in the grid map
% Output:
% grid_mat --- the grid matrix using grid index (xGrid, yGrid)
%--------------------------------------------------------------------------

function [grid_mat] = convertLocToGrid(loc_mat, mpc, nx, ny)

% the grid maximum index for x and y axis
grid_max = zeros(size(loc_mat));
grid_max(:,1) = nx;
grid_max(:,2) = ny;

% the grid minimum index for x and y axis
grid_min = 1;

% get grid index in the range of [grid_min, grid_max]
grid_mat = floor(loc_mat./mpc);
grid_mat = min(max(grid_mat, grid_min), grid_max);