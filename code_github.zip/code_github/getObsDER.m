%%-------------------------------------------------------------------------
% Get the derivative (gradient) of wind speed
% Input:
%       g_mat --- m x n spatial indicator; 1:non-obstacle; 0:obstacle
%         mpc --- mile per cell (size of cell)
% Output:
%          gx --- m x n gradient matrix dg/dx along vertical axis (top to bottom)
%          gy --- m x n gradient matrix dg/dy along horizontal axis (left to right)
%--------------------------------------------------------------------------
function [gx, gy] = getObsDER(g_mat, mpc)
[n1,n2] = size(g_mat);  

%% Initialize output matrix
gx = zeros(n1, n2);
gy = zeros(n1, n2);

%% Calculate dg/dy
gy(:, 1:(n2-1)) = double(g_mat(:, 2:n2)) - double(g_mat(:, 1:(n2-1)));
gy(:, n2) = double(gy(:,n2-1));
gy = gy / mpc;

%% Calculate dg/dx
gx(1:(n1-1), :) = double(g_mat(2:n1, :)) - double(g_mat(1:(n1-1), :));
gx(n1, :) = double(gx(n1-1, :));
gx = gx / mpc;