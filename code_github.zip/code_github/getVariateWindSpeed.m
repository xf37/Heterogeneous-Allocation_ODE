%%-------------------------------------------------------------------------
% Get speed, its gradient, and binary drone area in given location and time
% Input:
%      uCell ---- 1 x T cells (cell: m x n wind speed matrix along x axis across T time periods)
%      vCell ---- 1 x T cells (cell: m x n wind speed matrix along y axis across T time periods)
%          t ---- current time
%        spg ---- seconds per time grid
% Output:
%       uMat ---- m x n wind speed matrix along x axis at time t
%       vMat ---- m x n wind speed matrix along y axis at time t
%-------------------------------------------------------------------------

function [uMat, vMat] = getVariateWindSpeed(uCell, vCell, spg, t)

% Get the maximum time 
T = length(uCell);

% Get the neighbourhood time grid
start_grid = floor(t/spg);
end_grid = start_grid + 1;

if start_grid == 0
    uMat = uCell{1,1};
    vMat = vCell{1,1};
elseif start_grid == T
    uMat = uCell{1,T};
    vMat = vCell{1,T};
else
    % get the neighbourhood wind index
    start_weight = t - start_grid * spg;
    end_weight = end_grid * spg - t;
    
    % get the neighbourhood wind speed along x axis
    start_u = uCell{1,start_grid};
    end_u = uCell{1,end_grid};
    
    % get the neighbourhood wind speed along y axis
    start_v = vCell{1,start_grid};
    end_v = vCell{1,end_grid};
    
    % use the weighted wind speed to represent uMat and vMat
    uMat = (start_weight * start_u + end_weight * end_u) / (start_weight + end_weight);
    vMat = (start_weight * start_v + end_weight * end_v) / (start_weight + end_weight);
end

