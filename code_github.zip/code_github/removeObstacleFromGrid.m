%%-------------------------------------------------------------------------
% Remove obstacle area from the shortest flight time grid
% Input:
%      flightTimeGrid --- the shortest flight time in each grid
%             obs_mat --- the binary obstacle matrix
%                 mpc --- the mile per cell from original matrix
% Output:
%      flightTimeGrid --- the updated shortest flight time in each grid, 
%                         where the flight time in obstacle grids is zero
%--------------------------------------------------------------------------
function [flightTimeGrid] = removeObstacleFromGrid(flightTimeGrid, obs_mat, mpc)

%% get the dimension parameter
% get the size of original matrix
[n_row, n_col] = size(obs_mat);

% get the size of flight time grid
[n_grid_row, n_grid_col] = size(flightTimeGrid);

%% get the obstacle grid based on original obstacle matrix
% initialize the obstacle grid
obs_grid = zeros(n_grid_row, n_grid_col);

% map original obstacle matrix to obstacle grid
for i = 1:n_grid_row
    for j = 1:n_grid_col
        row_ind = max(floor(i / n_grid_row * n_row), 1);
        col_ind = max(floor(j / n_grid_col * n_col), 1);
        if obs_mat(row_ind, col_ind) == 1
            obs_grid(i, j) = 1;
        end
    end
end

%% set the flight time in obstacle area as 0
flightTimeGrid(obs_grid == 1) = NaN;