%%-------------------------------------------------------------------------
% update allocation cluster and allocation time
% Input:
%                     marker --- the current marker matrix recording 
%                                1. initial location along x-axis in miles,
%                                2. initial location along y-axis in miles,
%                                3. its head angle theta, 
%                                4. its hospital index
%                                5. its marker index
%                      T_res --- the cell recording the grid of time the markers arrive
%                                each element is n x 1 vector (time)
%                                the i-th element is the i-th (row) drone in the (marker)
%                    Loc_res --- the cell recording the path the markers pass
%                                each element is n x 3 vector (x (miles), y (miles), theta)
%                                the i-th element is the i-th (row) drone in the (marker)
%         allocation_cluster --- current allocation index at each grid
%            allocation_time --- current allocated time at each grid
% Output:
%         allocation_cluster --- updated allocation index at each grid
%            allocation_time --- updated allocated time at each grid
%         contributed_marker --- a column vector of the marker indices
%                                that contributed to the shortest
%                                allocation time
%                     marker --- the updated marker matrix
%                                (the position gets updatd)
%                                recording
%                                1. current location along x-axis in miles,
%                                2. current location along y-axis in miles,
%                                3. its head angle theta, 
%                                4. its hospital index
%                                5. its marker index
%--------------------------------------------------------------------------

function [allocation_cluster, allocation_time, contributed_marker, marker] = updateAllocation(marker, T_res, Loc_res, allocation_cluster, allocation_time, mpc, nx, ny)

% get the number of markers
n_marker = size(Loc_res, 2);

% create a null vector for contributed_marker, 
% at most n_marker markers can be selected
contributed_marker = zeros(n_marker, 1);
n_selected_marker = 1;

for i = 1:n_marker
    
    % initialize the binary variable to record
    % whether this marker has contribution to allocation result
    marker_has_contribution = 0;
    
    % get hospital index
    hospital_index = marker(i,4);  
    
    % get marker index
    marker_index = marker(i,5);

    % get marker's path and time
    marker_path = Loc_res{1, i}; % (x,y,theta) along drone's path
    marker_time = T_res{1, i}; % time along drone's path    
    marker_loc = marker_path(:,1:2); % marker's location (x,y) along the path
    
    % update marker's current location and head angle
    marker(i, 1:3) = marker_path(end, :);
    
    % map path matrix to grid matrix
    marker_loc_grid_mat = convertLocToGrid(marker_loc, mpc, nx, ny);
    
    % update the shortest time in each grid
    for j = 1:size(marker_loc_grid_mat, 1)
        grid_x = marker_loc_grid_mat(j,1);
        grid_y = marker_loc_grid_mat(j,2);
        
        if marker_time(j,1) <= allocation_time(grid_x, grid_y)
            % update the allocation time in each grid
            allocation_time(grid_x, grid_y) = marker_time(j,1);

            % update the allocation cluster in each grid
            allocation_cluster(grid_x, grid_y) = hospital_index;
            
            % whether this marker has contribution to allocation result
            marker_has_contribution = 1;
        end
    end
    
    if marker_has_contribution == 1
        % update the allocation marker index in each grid
        contributed_marker(n_selected_marker, 1) = marker_index;
        n_selected_marker = n_selected_marker + 1;
    end
end

contributed_marker = contributed_marker(1:(n_selected_marker-1), 1);

