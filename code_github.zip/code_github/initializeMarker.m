%%-------------------------------------------------------------------------
% Initialize the status and index for each marker
% Input:
%         n_angle --- number of marker for each hosptial
%     med_row_ind --- the vector recroding hospitals' row indices
%     med_col_ind --- the vector recroding hospitals' column indices
%             mpc --- mile per cell (size of cell)
% Output:
%         marker  --- the matrix recording 
%                     1. initial location along row (vertical)-axis in miles,
%                     2. initial location along column (horizonal)-axis in miles,
%                     3. its head angle theta, 
%                     4. its hospital index
%                     5. its marker index,   
%--------------------------------------------------------------------------

function [marker] = initializeMarker(n_angle, med_row_ind, med_col_ind, mpc)

n_hospital = size(med_row_ind, 1);
marker = zeros(n_angle * n_hospital, 5);

% calculate hospital locations
med_row_loc = med_row_ind * mpc;
med_col_loc = med_col_ind * mpc;

% initialize the head angles
head_angle = (2 * pi / n_angle * (1:n_angle))';

% initialize marker index
marker(:,5) = (1:n_angle * n_hospital)';

for i = 1:n_hospital
    marker((((i-1)*n_angle+1) : (i*n_angle)), 1) = med_row_loc(i,1) * ones(n_angle, 1);
    marker((((i-1)*n_angle+1) : (i*n_angle)), 2) = med_col_loc(i,1) * ones(n_angle, 1);
    marker((((i-1)*n_angle+1) : (i*n_angle)), 3) = head_angle;
    marker((((i-1)*n_angle+1) : (i*n_angle)), 4) = i;
end
