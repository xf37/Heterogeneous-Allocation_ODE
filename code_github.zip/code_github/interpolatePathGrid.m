%%-------------------------------------------------------------------------
% Map Drone's path to grid and summarize flight time
% Input:
%              path --- 1 x n_facility cell
%                       each element is n x 3 matrix recording the unique 
%                       location and flight time matrix for each facility
%        n_grid_row --- the number of rows in the output grid
%        n_grid_col --- the number of columns in the output grid
%             n_row --- the number of rows in the original region
%             n_col --- the number of columns in the original region
%          obs_grid --- n_grid_row x n_grid_col binary matrix recoding
%                       obstacle. 1: obstacle; 0: non-obstacle
%          sea_grid --- n_grid_row x n_grid_col binary matrix recoding sea;
%                       1: sea; 0: land
%          med_grid --- n_grid_row x n_grid_col binary matrix recoding
%                       facility. 1: facility; 0: land
%               mpc --- mile per cell in the original region
%       time_period --- the maximum flight time
%       drone_speed --- drone speed
% Output:
%   flightTimeGrid --- the shortest flight time in each grid
%      clusterGrid --- the facility index where the best marker (with
%                      shortest flight time) comes from
%--------------------------------------------------------------------------

function [flightTimeGrid, allocationGrid] = interpolatePathGrid(path, ...
    n_grid_row, n_grid_col, n_row, n_col, obs_grid, sea_grid, ...
    med_grid, mpc)

%% calculate the mile per grid according to current grids
mpg_x = mpc * n_row / n_grid_row;
mpg_y = mpc * n_col / n_grid_col;

%% map the path to the grid
% get the number of facilities
n_facility = size(path, 2); 

% initialize the result grid
flightTimeGrid = ones(n_grid_row, n_grid_col) * 1e+10;
allocationGrid = zeros(n_grid_row, n_grid_col);

% set flight time in facility grid as 0
flightTimeGrid(med_grid == 1) = 0;

% get the row grid and column grid that is not in obstacle or sea
[row_grid, col_grid] = find((obs_grid == 0) & (sea_grid == 0)); 

for i = 1:n_facility
    % get the location of facility
    
    % get the path for each facility
    path_per_facility = path{1, i};
    
    % map the location in mile to the row and column indices
    path_per_facility(:,1) = path_per_facility(:,1) / mpg_x;
    path_per_facility(:,2) = path_per_facility(:,2) / mpg_y;

    % interpolate the path to flight time grid
    F = scatteredInterpolant(path_per_facility(:,1),...
        path_per_facility(:,2), path_per_facility(:,3));
    F.Method = 'linear';  

    % update the facility cluster in each grid inside the convex full
    interpolate_val_vec = max(F(row_grid,col_grid), 0);
    
    % de-noise: remove the grids whose interpolation values are less than 5s
    row_grid_iter = row_grid(interpolate_val_vec > 5, :);
    col_grid_iter = col_grid(interpolate_val_vec > 5, :);
    interpolate_val_vec = interpolate_val_vec(interpolate_val_vec > 5, :);
    
    % get interpolate value matrix
    interpolate_val_mat = ones(n_grid_row, n_grid_col) * 1e+11;
    n_grid_area = size(interpolate_val_vec,1);
    for grid_index = 1:n_grid_area
        interpolate_val_mat(row_grid_iter(grid_index), col_grid_iter(grid_index)) = interpolate_val_vec(grid_index);
    end
    
    % update the cluster result
    allocationGrid(interpolate_val_mat <= flightTimeGrid) = i;
    
    % update the shortest flight time in each grid
    flightTimeGrid = min(interpolate_val_mat, flightTimeGrid);
end

% set flight time as 0s in facility location
flightTimeGrid(med_grid > 0) = 0;