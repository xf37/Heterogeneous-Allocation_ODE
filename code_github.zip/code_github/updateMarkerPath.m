%%-------------------------------------------------------------------------
% Update all markers' paths
% Input:
%           marker --- the current marker matrix recording 
%                      1. initial location along x-axis in miles,
%                      2. initial location along y-axis in miles,
%                      3. its head angle theta, 
%                      4. its hospital index
%                      5. its marker index
%      marker_path --- the cell recording each marker's path, 
%                      each element is (n x 4) matrix, which
%                      recordes (x (miles), y (miles), theta, time)
%            T_res --- the cell recording the grid of time the markers arrive
%                      each element is n x 1 vector (time)
%          Loc_res --- the cell recording the path the markers pass
%                      each element is n x 3 vector (x (miles), y (miles), theta)
% Output:
%      marker_path --- the updated marker_path cell
%--------------------------------------------------------------------------

function [marker_path] = updateMarkerPath(marker, marker_path, T_res, Loc_res)

% number of marker
n_marker = size(Loc_res, 2);

if isempty(marker_path{1,1}) % create matrix when marker_path is empty
    for i = 1:n_marker
        marker_path{1, i} = [Loc_res{1, i} T_res{1, i}];
    end    
else % append new marker_path matrix
    for i = 1:n_marker
        marker_index = marker(i, 5);
        each_marker_path = [Loc_res{1, i} T_res{1, i}];
        marker_path{1, marker_index} = [marker_path{1, marker_index}; each_marker_path];
    end   
end